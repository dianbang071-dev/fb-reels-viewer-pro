# FB Reels Viewer Pro — Android Studio project

## Fitur versi 1.0
- Masukkan / tempel URL Facebook Reel dan buka di WebView.
- Validasi domain Facebook dan fb.watch.
- Tombol reload, fullscreen immersive, back/forward, bagikan URL.
- Riwayat hingga 50 URL dan daftar favorit.
- Auto reload 15 detik hingga 10 menit atau nonaktif.
- Opsi menjaga layar tetap menyala, bersihkan cache.
- Penyimpanan URL terakhir.

## Cara membuat APK
1. Ekstrak ZIP ini di komputer Windows.
2. Install Android Studio versi stabil dan Android SDK Platform 35.
3. Buka Android Studio > Open > pilih folder `FB_Reels_Viewer_Pro`.
4. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan penting
Aplikasi ini menampilkan situs/player resmi Facebook di dalam WebView. Keberhasilan playback bergantung pada login, izin, format URL, koneksi, dan kebijakan Facebook. Facebook dapat mengubah halaman atau memblokir WebView; bila terjadi, gunakan menu browser Facebook atau buka URL di Chrome. Autoplay tidak dijamin karena Facebook dan Android dapat mensyaratkan interaksi pengguna. Auto reload memuat ulang halaman, bukan menjamin video mulai otomatis. Aplikasi ini tidak mengunduh atau mengekstrak video dan tidak melewati privasi/akses akun Facebook.

Versi ini adalah proyek sumber Android Studio, bukan APK yang sudah dikompilasi. Tidak disertakan kredensial atau layanan pihak ketiga.
