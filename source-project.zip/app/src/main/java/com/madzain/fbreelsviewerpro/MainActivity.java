package com.madzain.fbreelsviewerpro;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import org.json.JSONArray;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, toolbar, controls;
    private EditText urlInput;
    private WebView web;
    private TextView status;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable reloadTask;
    private boolean fullscreen = false;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private int reloadSeconds = 0;
    private SharedPreferences prefs;

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(10),dp(10),dp(10),dp(10)); return t;
    }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(13); b.setBackground(bg(Color.rgb(36,48,60),12));
        b.setOnClickListener(v -> action.run()); return b;
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("viewer", MODE_PRIVATE);
        buildUi(); configureWeb();
        String last = prefs.getString("last_url", "");
        if (!last.isEmpty()) urlInput.setText(last);
        if (!last.isEmpty()) loadUrl(last);
    }
    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9,13,18)); root.setPadding(dp(12),dp(8),dp(12),dp(8));
        setContentView(root);

        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("▶  FB REELS VIEWER PRO",18,Color.WHITE);
        brand.setGravity(Gravity.CENTER_VERTICAL); brand.setTypeface(null,1);
        header.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        header.addView(button("⋮", this::showMenu),new LinearLayout.LayoutParams(dp(52),dp(44)));
        root.addView(header);

        urlInput = new EditText(this); urlInput.setSingleLine(true); urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.GRAY); urlInput.setHint("Tempel URL Facebook Reel di sini");
        urlInput.setTextSize(14); urlInput.setPadding(dp(12),0,dp(12),0);
        urlInput.setBackground(bg(Color.rgb(26,34,43),12));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,dp(50)); ip.setMargins(0,dp(8),0,dp(8));
        root.addView(urlInput,ip);

        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button open = button("BUKA REEL", () -> submitUrl());
        row.addView(open,new LinearLayout.LayoutParams(0,dp(46),1));
        Button paste = button("TEMPEL", () -> pasteUrl());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(100),dp(46)); pp.setMargins(dp(6),0,0,0);
        row.addView(paste,pp); root.addView(row);

        controls = new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0,dp(7),0,dp(7));
        controls.addView(button("↻ Reload", () -> web.reload()),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("⛶ Layar penuh", () -> toggleFullscreen()),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("★ Favorit", () -> saveFavorite()),new LinearLayout.LayoutParams(0,dp(42),1));
        root.addView(controls);

        status = text("Siap — masukkan URL Facebook Reel",12,Color.LTGRAY);
        status.setGravity(Gravity.CENTER_VERTICAL); root.addView(status,new LinearLayout.LayoutParams(-1,dp(30)));

        web = new WebView(this);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1,0,1);
        root.addView(web,wp);

        LinearLayout bottom = new LinearLayout(this); bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(button("←", () -> { if(web.canGoBack()) web.goBack(); }),new LinearLayout.LayoutParams(0,dp(44),1));
        bottom.addView(button("→", () -> web.goForward()),new LinearLayout.LayoutParams(0,dp(44),1));
        bottom.addView(button("Bagikan", () -> shareUrl()),new LinearLayout.LayoutParams(0,dp(44),1));
        bottom.addView(button("Riwayat", () -> showHistory()),new LinearLayout.LayoutParams(0,dp(44),1));
        root.addView(bottom);
    }
    private void configureWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false); s.setLoadsImagesAutomatically(true);
        s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true); s.setSupportZoom(true);
        s.setBuiltInZoomControls(true); s.setDisplayZoomControls(false);
        s.setUserAgentString("Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true);
        web.setBackgroundColor(Color.BLACK);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("https://") || u.startsWith("http://")) return false;
                return true;
            }
            @Override public void onPageStarted(WebView v,String u,android.graphics.Bitmap f) {
                status.setText("Memuat: " + host(u));
            }
            @Override public void onPageFinished(WebView v,String u) {
                status.setText("Halaman siap • " + host(u));
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) status.setText("Gagal memuat. Periksa koneksi atau URL.");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) { callback.onCustomViewHidden(); return; }
                customView = view; customCallback = callback; fullscreen = true;
                root.setVisibility(View.GONE);
                addContentView(view,new ViewGroup.LayoutParams(-1,-1));
                getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
            }
            @Override public void onHideCustomView() { exitFullscreen(); }
            @Override public void onProgressChanged(WebView v,int p) {
                if(p==100) status.setText("Video/page selesai dimuat");
            }
        });
    }
    private String host(String u) { try { return Uri.parse(u).getHost(); } catch(Exception e){return "Facebook";} }
    private void submitUrl() {
        String u=urlInput.getText().toString().trim();
        if(u.isEmpty()){ urlInput.setError("Masukkan URL Reel"); return; }
        if(!u.startsWith("http://") && !u.startsWith("https://")) u="https://"+u;
        Uri uri=Uri.parse(u); String h=uri.getHost();
        if(h==null || !(h.equals("facebook.com") || h.endsWith(".facebook.com") || h.equals("fb.watch") || h.endsWith(".fb.watch"))) {
            urlInput.setError("Gunakan URL facebook.com atau fb.watch"); return;
        }
        loadUrl(u);
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(urlInput.getWindowToken(),0);
    }
    private void loadUrl(String u) {
        urlInput.setText(u); prefs.edit().putString("last_url",u).apply();
        addHistory(u); web.loadUrl(u); scheduleReload();
    }
    private void pasteUrl() {
        android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if(cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount()>0) {
            CharSequence x=cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if(x!=null) urlInput.setText(x.toString());
        } else Toast.makeText(this,"Clipboard kosong",Toast.LENGTH_SHORT).show();
    }
    private void scheduleReload() {
        if(reloadTask!=null) handler.removeCallbacks(reloadTask);
        if(reloadSeconds>0) {
            reloadTask=()->{ if(!isFinishing() && web!=null){ web.reload(); handler.postDelayed(reloadTask,reloadSeconds*1000L); } };
            handler.postDelayed(reloadTask,reloadSeconds*1000L);
        }
    }
    private void showMenu() {
        String[] opts={"Atur auto reload","Matikan auto reload","Tetap nyala / layar","Buka Facebook beranda","Bersihkan cache"};
        new AlertDialog.Builder(this).setTitle("Pengaturan Viewer").setItems(opts,(d,w)->{
            if(w==0) setReload(); else if(w==1){reloadSeconds=0;if(reloadTask!=null)handler.removeCallbacks(reloadTask);status.setText("Auto reload nonaktif");}
            else if(w==2){boolean on=(getWindow().getAttributes().flags & android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)!=0;
                if(on)getWindow().clearFlags(128);else getWindow().addFlags(128);
                Toast.makeText(this,on?"Layar boleh mati":"Layar akan tetap menyala",Toast.LENGTH_SHORT).show();}
            else if(w==3) loadUrl("https://m.facebook.com/");
            else if(w==4){web.clearCache(true);web.clearHistory();Toast.makeText(this,"Cache dibersihkan",Toast.LENGTH_SHORT).show();}
        }).show();
    }
    private void setReload() {
        final String[] labels={"15 detik","30 detik","1 menit","2 menit","5 menit","10 menit"};
        final int[] values={15,30,60,120,300,600};
        new AlertDialog.Builder(this).setTitle("Interval auto reload").setItems(labels,(d,w)->{
            reloadSeconds=values[w];scheduleReload();status.setText("Auto reload setiap "+labels[w]);
        }).show();
    }
    private void toggleFullscreen() {
        if(fullscreen){exitFullscreen();return;}
        getWindow().getDecorView().setSystemUiVisibility(5894|1024|512);
        root.setVisibility(View.GONE); fullscreen=true;
        // WebView stays attached; system bars are hidden for an immersive viewing area.
    }
    private void exitFullscreen() {
        if(customView!=null){ ((ViewGroup)customView.getParent()).removeView(customView); customView=null;
            if(customCallback!=null)customCallback.onCustomViewHidden(); customCallback=null; }
        fullscreen=false; root.setVisibility(View.VISIBLE); getWindow().getDecorView().setSystemUiVisibility(0);
    }
    private void saveFavorite() {
        String u=urlInput.getText().toString().trim(); if(u.isEmpty()){Toast.makeText(this,"Tidak ada URL",0).show();return;}
        JSONArray a=new JSONArray(); try { JSONArray old=new JSONArray(prefs.getString("favorites","[]"));
            for(int i=0;i<old.length();i++)a.put(old.getString(i)); if(!a.toString().contains(u))a.put(u);
        }catch(Exception e){a.put(u);}
        prefs.edit().putString("favorites",a.toString()).apply(); Toast.makeText(this,"Disimpan ke favorit",0).show();
    }
    private void addHistory(String u) {
        try { JSONArray old=new JSONArray(prefs.getString("history","[]")); JSONArray a=new JSONArray(); a.put(u);
            for(int i=0;i<old.length() && i<49;i++) if(!old.getString(i).equals(u))a.put(old.getString(i));
            prefs.edit().putString("history",a.toString()).apply();
        }catch(Exception e){}
    }
    private void showHistory() {
        try {
            JSONArray a=new JSONArray(prefs.getString("history","[]")); if(a.length()==0){Toast.makeText(this,"Riwayat kosong",0).show();return;}
            String[] items=new String[a.length()]; for(int i=0;i<a.length();i++)items[i]=a.getString(i);
            new AlertDialog.Builder(this).setTitle("Riwayat URL").setItems(items,(d,w)->loadUrl(items[w]))
                .setNeutralButton("Favorit",(d,w)->showFavorites()).show();
        }catch(Exception e){}
    }
    private void showFavorites() {
        try { JSONArray a=new JSONArray(prefs.getString("favorites","[]")); if(a.length()==0){Toast.makeText(this,"Favorit kosong",0).show();return;}
            String[] items=new String[a.length()];for(int i=0;i<a.length();i++)items[i]=a.getString(i);
            new AlertDialog.Builder(this).setTitle("Favorit").setItems(items,(d,w)->loadUrl(items[w])).show();
        }catch(Exception e){}
    }
    private void shareUrl() {
        String u=urlInput.getText().toString().trim(); if(u.isEmpty())return;
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_TEXT,u);
        startActivity(Intent.createChooser(i,"Bagikan URL Reel"));
    }
    @Override public void onBackPressed() {
        if(fullscreen){exitFullscreen();return;}
        if(web!=null && web.canGoBack())web.goBack();else super.onBackPressed();
    }
    @Override protected void onDestroy(){if(reloadTask!=null)handler.removeCallbacks(reloadTask);if(web!=null)web.destroy();super.onDestroy();}
}